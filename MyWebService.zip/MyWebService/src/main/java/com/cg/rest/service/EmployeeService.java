package com.cg.rest.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.rest.dto.Employee;

@Service
public class EmployeeService {

	List<Employee> employees =new ArrayList<Employee>(Arrays.asList(
			new Employee(1001,"Anil","Male",22,5000),
			new Employee(1002,"Binu","Male",22,6000)));
	
	public List<Employee> getEmployees(){
		return employees;
	}
	
	public Employee getEmployeeById(int id) {
		return employees.stream().filter(e->e.getId()==id).findFirst().get();
	}
	
	public void addEmployee(Employee emp) {
		employees.add(emp);
	}
	
	public void updateEmployee(Employee emp,int id) {
		for(int i=0;i<employees.size();i++) {
			if(employees.get(i).getId()==emp.getId()) {
				employees.set(i, emp);
				return;
			}
		}
	}
	
	public void deleteEmployee(int id) {
		employees.removeIf(e->e.getId()==id);
	}
}
