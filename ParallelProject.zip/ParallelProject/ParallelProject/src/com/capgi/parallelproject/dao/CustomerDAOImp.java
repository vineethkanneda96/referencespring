package com.capgi.parallelproject.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.bean.Transaction;
import com.capgi.parallelproject.exception.CustomerNotFound;

public class CustomerDAOImp implements ICustomerDAO {
	//Map<Long, Customer> custList = new HashMap<Long, Customer>();
	//Map<Long, StringBuffer> transaction = new HashMap<Long, StringBuffer>();
	Transaction transaction=new Transaction();
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
	@Override
	public boolean createAccount(Customer cus) throws CustomerNotFound{
		
		EntityManager em=factory.createEntityManager();
			try{
				
				em.getTransaction().begin();
				em.persist(cus);
				em.getTransaction().commit();
				return em.contains(cus);
			}catch(PersistenceException e) {
				e.printStackTrace();
				//TODO: Log to file
				throw new CustomerNotFound(e.getMessage());
			}finally {
				em.close();
			}
	}

	@Override
	public double showBalance(int cid,int pin) throws CustomerNotFound{
		double a=0;
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		Customer customer=new Customer();
		try{
			//entityManager=JPAUtil.getEntityManager();
			//entityManager=Persistence.createEntityManagerFactory("ParallelProject").createEntityManager();
			customer=em.find(Customer.class,cid);
			if(customer==null){
				return a;
			}
			else if(customer.getAccountNo()==cid&&customer.getPin()==pin){
			a=customer.getBalance();
			//System.out.println("Balance is:"+a);
			return a;
			}
			return a;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
	}

	@Override
	public double deposit(Customer c,int accountNo,int pin, double amount) throws CustomerNotFound{
		
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();
		/*Session session = em.unwrap(Session.class);
		SessionFactory sessionFactory = em.getEntityManagerFactory().unwrap(SessionFactory.class);*/
		try{
			if(c==null){
				return 0.0;
			}
			else if(c.getAccountNo()==accountNo&&c.getPin()==pin){
			em.getTransaction().begin();
			double newBal=0;
			newBal=c.getBalance()+amount;
			int s1=transaction.getSlNo();
			String c1="     "+(s1+1)+"\t\t"+dateFormat.format(date)+"\t\t\t\t\t"+amount+"\t\t"+newBal;
			transaction.setTransaction(c1);
			//em.merge(transaction);
			c.setBalance(newBal);
			c.addTransaction(transaction);
			em.merge(c);
			em.getTransaction().commit();
			transaction.setSlNo(s1+1);
			return c.getBalance();
			}else{
				return 0.0;
			}
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound("nOT fOUND"+e.getMessage());
		}finally {
			em.close();
		}
	}

	@SuppressWarnings("null")
	@Override
	public double withDraw(Customer c,int accountNo,int pin, double amount) throws CustomerNotFound{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();
		EntityManager em=factory.createEntityManager();
		if(c==null){
			return c.getBalance();
		}
		else if(c.getAccountType().equals("Savings Account")&&(c.getBalance()-amount>500)){
		    try{
		    	if(c.getAccountNo()==accountNo&&c.getPin()==pin){
			em.getTransaction().begin();
			double newBal=0;
			newBal=c.getBalance()-amount;
			int s1=transaction.getSlNo();
			transaction.setTransaction("     "+(s1+1)+"\t\t"+dateFormat.format(date)+"\t\t"+amount+"\t\t\t\t\t"+newBal);
			//em.merge(transaction);
			c.setBalance(newBal);
			c.addTransaction(transaction);
			em.merge(c);
			em.getTransaction().commit();
			transaction.setSlNo(s1+1);
			return c.getBalance();
		    }else{
		    	return c.getBalance();
		       }
		    }
		    	catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		    }finally {
			em.close();
		    }
		}else if(c.getAccountType().equals("Current Account")&&(c.getBalance()-amount>-2000)){
		    try{
		    	if(c.getAccountNo()==accountNo&&c.getPin()==pin){
			em.getTransaction().begin();
			double newBal=0;
			newBal=c.getBalance()-amount;
			int s1=transaction.getSlNo();
			transaction.setTransaction("     "+(s1+1)+"\t\t"+dateFormat.format(date)+"\t\t"+amount+"\t\t\t\t\t"+newBal);
			//em.merge(transaction);
			c.addTransaction(transaction);
			c.setBalance(newBal);
			em.merge(c);
			em.getTransaction().commit();	
			transaction.setSlNo(s1+1);
			return c.getBalance();
		    }else{
		    	return c.getBalance();
		    }
		    }catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		    }finally {
			em.close();
		    }
		}
		return c.getBalance();
	}

	@Override
	public boolean fundTransfer(Customer c,Customer b,double amount, int acc1, int acc2, int pin1) throws CustomerNotFound{
		// TODO Auto-generated method stub
		boolean flag=false;
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date=new Date();
		if(c==null){
			return flag;
		}
		else if(c.getAccountNo()==acc1&&c.getPin()==pin1){
			if(b.getAccountNo()==acc2){
				if(c.getAccountType().equals("Savings Account")&&(c.getBalance()-amount>500)){
					EntityManager em=factory.createEntityManager();
				    try{
					em.getTransaction().begin();
					double bal=c.getBalance();
					bal=bal-amount;
					//em.merge(c);
					int s1=transaction.getSlNo();
					transaction.setTransaction("     "+(s1+1)+"\t\t"+dateFormat.format(date)+"\t\t"+amount+"\t\t\t\t\t"+bal+"\n\t\t\t\t\tTransfered From:"+c.getAccountNo()+"\n\t\t\t\t\t\tTo:"+b.getAccountNo());
					//em.merge(transaction);
					c.setBalance(bal);
					c.addTransaction(transaction);
					em.merge(c);
					double bal1=b.getBalance();
					bal1=bal1+amount;
					String c1="     "+(s1+1)+"\t\t"+dateFormat.format(date)+"\t\t\t\t\t"+amount+"\t\t"+bal1+"\n\t\t\t\t\t\t\tReceived From:"+c.getAccountNo()+"\n\t\t\t\t\t\t\t\t\tTo:"+b.getAccountNo();                                                    
					transaction.setTransaction(c1);
					//em.merge(transaction);
					b.setBalance(bal1);
					b.addTransaction(transaction);
					em.merge(b);
					em.getTransaction().commit();	
					transaction.setSlNo(s1+1);
					flag=true;
				    }catch(PersistenceException e) {
					e.printStackTrace();
					//TODO: Log to file
					throw new CustomerNotFound(e.getMessage());
				    }finally {
					em.close();
				    }
				}
				else if(c.getAccountType().equals("Current Account")&&(c.getBalance()-amount>-2000)){
					EntityManager em=factory.createEntityManager();
				    try{
					em.getTransaction().begin();
					double bal=c.getBalance();
					bal=bal-amount;
					//em.merge(c);
					int s1=transaction.getSlNo();
					transaction.setTransaction("     "+(s1+1)+"\t\t"+dateFormat.format(date)+"\t\t"+amount+"\t\t\t\t\t"+bal+"\n\t\t\t\t\tTransfered From:"+c.getAccountNo()+"\n\t\t\t\t\t\tTo:"+b.getAccountNo());
					                                                                              
					//em.merge(transaction);
					c.setBalance(bal);
					c.addTransaction(transaction);
					em.merge(c);
					double bal1=b.getBalance();
					bal1=bal1+amount;
					String c1="     "+(s1+1)+"\t\t"+dateFormat.format(date)+"\t\t\t\t\t"+amount+"\t\t"+bal1+"\n\t\t\t\t\t\t\tReceived From:"+c.getAccountNo()+"\n\t\t\t\t\t\t\t\t\t  To"+b.getAccountNo();
					transaction.setTransaction(c1);
					//transaction.setSlNo(s1);
					//em.merge(transaction);
					b.setBalance(bal1);
					b.addTransaction(transaction);
					em.merge(b);
					em.getTransaction().commit();
					transaction.setSlNo(s1+1);
					flag=true;
				    }catch(PersistenceException e) {
					e.printStackTrace();
					//TODO: Log to file
					throw new CustomerNotFound(e.getMessage());
				    }finally {
					em.close();
				    }
				}
			}
		}
		return flag;
	}

	@Override
	public List<Transaction> printTransactions(int cid,int pin) throws CustomerNotFound{
		// TODO Auto-generated method stub
		EntityManager em=factory.createEntityManager();
		try{
			Customer c=em.find(Customer.class, cid);
			if(c==null){
				return null;
			}
			else if(c.getAccountNo()==cid&&c.getPin()==pin){
			List<Transaction> passbookList=c.getTransactions();
			 return passbookList;
			}
			return null;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
	}
	
	/*@Override
	public Customer printTransaction(Customer cid,double deposit,int choice) throws CustomerNotFound{
		Customer cust=null;
		EntityManager em=factory.createEntityManager();
		try{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date=new Date();
			em.getTransaction().begin();
			Customer customer=em.find(Customer.class,cid);
			Transaction transaction=new Transaction();
			if(choice==3){
			transaction.setTransaction("     "+transaction.getSlNo()+"          "+dateFormat.format(date)+"          "+deposit+"                    "+cid.getBalance());
			customer.addTransaction(transaction);
			System.out.println("Transaction Recorded");
			}
			else if(choice==4){
				transaction.setTransaction("     "+transaction.getSlNo()+"          "+dateFormat.format(date)+"                    "+deposit+"          "+cid.getBalance());
				customer.addTransaction(transaction);
				System.out.println("Transaction Recorded");
			}
			em.merge(transaction);
			em.getTransaction().commit();
			return cust;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
		
	}*/

	public boolean validateAccountNumber(int cid) throws CustomerNotFound {
		// TODO Auto-generated method stub
		boolean flag=false;
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		try{
			//entityManager=JPAUtil.getEntityManager();
			Customer customer=em.find(Customer.class,cid);
			if(customer==null){
				flag=false;
			}else{
			if(customer.getAccountNo()==cid){
			flag=true;
			}else{
				flag=false;
				}
			}
			return flag;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
		
	}
	public boolean validatePin(int pin,int cid) throws CustomerNotFound {
		// TODO Auto-generated method stub
		boolean flag=false;
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		try{
			//entityManager=JPAUtil.getEntityManager();
			Customer customer=em.find(Customer.class,cid);
			if(customer==null){
				flag=false;
			}else{
			if(customer.getPin()==pin){
			flag=true;
			}else{
				flag=false;
			   }
			}
			return flag;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
	}

	@Override
	public Customer displayCustomer(int accNo) {
		// TODO Auto-generated method stub
		Customer custo=null;
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("ParallelProject");
		EntityManager em=factory.createEntityManager();
		try{
			//entityManager=JPAUtil.getEntityManager();
			custo=em.find(Customer.class,accNo);
			return custo;
		}
		catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			try {
				throw new CustomerNotFound(e.getMessage());
			} catch (CustomerNotFound e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			em.close();
		}
		return custo;
	}
}