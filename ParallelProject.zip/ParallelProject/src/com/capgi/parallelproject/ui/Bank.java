package com.capgi.parallelproject.ui;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.bean.Transaction;
import com.capgi.parallelproject.exception.CustomerNotFoundException;
import com.capgi.parallelproject.service.CustomerServiceImp;

public class Bank {
	private static CustomerServiceImp service = new CustomerServiceImp();
	public static void main(String[] args) throws CustomerNotFoundException{


		while (true) {
			System.out.println("*************************************************");
			System.out.println("-------------------------------------------------");
			System.out.println("WELCOME TO BANKING SYSTEM");
			System.out.println("-------------------------------------------------");
			System.out.println("*************************************************");
			System.out.println("ENTER 1 TO CREATE NEW ACCOUNT");
			System.out.println("ENTER 2 TO SHOW BALANCE");
			System.out.println("ENTER 3 FOR DEPOSIT");
			System.out.println("ENTER 4 TO WITHDRAW");
			System.out.println("ENTER 5 FOR FUND TRANSFER");
			System.out.println("ENTER 6 TO PRINT TRANSACTIONS");
			System.out.println("ENTER 7 TO EXIT");

			Scanner sc = new Scanner(System.in);
			int choice=sc.nextInt();
			switch (choice) {

			case 1:
				Customer bean=new Customer();
				boolean valid=false;
				do {

					BufferedReader customerFirstName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER CUSTOMER FIRSTNAME:");
						n=customerFirstName.readLine();
						String s=service.toTitleCase(n);
						bean.setCustomerFirstName(s);
						valid=service.validateCustomerFirstName(s);
						if(valid){
							break;
						}else{
							System.err.println("Please enter valid name. Name should contain atleast 2 letters.\nEx:Vineeth");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}

				} while (!valid);
				boolean valid1=false;
				do {
					BufferedReader customerMiddleName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER CUSTOMER MIDDLENAME:");
						n=customerMiddleName.readLine();
						//String s=service.toTitleCase(n);
						bean.setCustomerMiddleName(n);
						valid1=service.validateCustomerMiddleName(n);
						if(valid1){
							break;
						}else{
							System.err.println("Please enter valid name.\nEx:Vineeth");
						}
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				} while (!valid1);
				boolean valid2=false;
				do {
					BufferedReader customerLastName= new BufferedReader(new InputStreamReader(System.in));
					String n;
					try {
						System.out.println("ENTER CUSTOMER LASTNAME:");
						n=customerLastName.readLine();
						String s=service.toTitleCase(n);
						bean.setCustomerLastName(s);
						valid2=service.validateCustomerLastName(s);
						if(valid2){
							break;
						}else{
							System.err.println("Please enter valid name. Name should contain atleast 2 letters.\nEx:Vineeth");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				} while (!valid2);
				boolean valid3=false;
				do{
					System.out.println("ENTER MOBILE NO:");
					String mobileNo1="+(0/91)-";
					String mobileNo2=sc.next();
					String mobileNo=mobileNo1.concat(mobileNo2);
					valid3=service.validateMobileNo(mobileNo2,bean);
					if(valid3){
						bean.setMobileNo(mobileNo);
						break;
					}else{
						System.err.println("Please enter valid mobile number. It should be 10digit Number");
					}
				}while(!valid3);
				boolean valid4=false;
				do{
					System.out.println("ENTER AGE");
					String age = sc.next();
					bean.setAge(age);
					valid4=service.validateAge(age);
					if(valid4){
						break;
					}else{
						System.err.println("Please enter valid age. Age is a number between 0 and 100");
					}
				}while(!valid4);
				boolean valid5=false;
				do{
					System.out.println("ENTER GENDER");
					String gender=sc.next().toUpperCase();
					bean.setGender(gender);
					valid5=service.validateGender(gender,bean);
					if(valid5){
						break;
					}else{
						System.err.println("Please enter valid gender. Please select  M for Male or F for Female");
					}
				}while(!valid5);
				boolean valid11=false;
				do{
					System.out.println("ENTER DATE OF BIRTH IN dd/mm/yyyy FORMAT");
					String dob=sc.next();
					valid11=service.validateDateOfBirth(dob);
					if(valid11){
						bean.setBirthdate(dob);
						break;
					}else{
						System.err.println("Please enter valid Date of Birth. It should be in DD-MM-YYYY FORMAT");
					}
				}while(!valid11);
				boolean valid6=false;
				do{
					System.out.println("ENTER EMAIL-ADDRESS:");
					String email=sc.next();
					valid6=service.validateEmailAddress(email);
					if(valid6){
						bean.setEmail(email);
						break;
					}else{
						System.err.println("Please enter valid email address.\n vineeth@gmail.com");
					}
				}while(!valid6);
				int valid7=0;
				do{
					System.out.println("ENTER A GOVERNMENT ID DETAILS:");
					System.out.println("ENTER 1 FOR PANCARD");
					System.out.println("ENTER 2 FOR AADHAR");
					System.out.println("ENTER 3 FOR VOTERID");
					System.out.println("ENTER 4 FOR DRIVING LICENSE:");
					int choice1=sc.nextInt();
					if(choice1==1){
						System.out.println("ENTER PANCARD NO.");
						String panNo=sc.next().toUpperCase();
						valid7=service.validatePanNo(panNo);
						if(valid7==1){
							bean.setGovtId("Pan No:"+panNo);
							break;
						}else{
							System.err.println("Please enter valid pan no.\n Ex:QWERT5678U");
						}
					}
					else if(choice1==2){
						System.out.println("ENTER AADHAR NO.:");
						String aadharNo=sc.next();
						valid7=service.validateAadharNo(aadharNo);
						if(valid7==1){
							bean.setGovtId("Aadhar No:"+aadharNo);
						}else{
							System.err.println("Please enter valid Aadhar no.\n It should be 12 digit Number.");
						}
					}

					else if(choice1==3){
						System.out.println("ENTER VOTER ID NO.:");
						String voterId=sc.next().toUpperCase();
						valid7=service.validateVoterId(voterId);
						if(valid7==1){
							bean.setGovtId("Voter Id:"+voterId);
						}else{
							System.err.println("Please enter valid Voter id no.\n Ex:QWE1234567");
						}
					}
					else if(choice1==4){
						System.out.println("ENTER DRIVING LICENSE NO.:");
						String drivingLicenseNo=sc.next();
						valid7=service.validatedrivingLicenseNo(drivingLicenseNo);
						if(valid7==1){
							bean.setGovtId("Driving License:"+drivingLicenseNo);
						}else{
							System.err.println("Please enter valid Driving License No.\n Ex:TS1234567890987");
						}
					}
					else{
						System.err.println("Please enter valid choice");
					}
				}while(valid7==0);
				boolean valid8=false;
				do{
					System.out.println("ENTER CUSTOMER ADDRESS:");
					System.out.println("H.No./Flat No.");
					String address1=sc.next();
					System.out.println("Street Name/Colony Name/Area");
					String address2=sc.next();
					System.out.println("City");
					String address3=sc.next();
					System.out.println("State");
					String address4=sc.next();
					System.out.println("Pincode");
					String address5=sc.next();
					boolean valid9=service.validatePinCode(address5);
					if(valid9){
						String address=address1.concat(", "+address2).concat(", "+address3).concat(", "+address4).concat("-"+address5);

						valid8=service.validateAddress(address);
						if(valid8){
							bean.setAddress(address);
							break;
						}else{
							System.err.println("Please enter valid address");
						}
					}else{
						System.err.println("Please enter valid Pincode. Pincode is a 6digit Number");
					}
				}while(!valid8);
				boolean valid10=false;
				do{
					System.out.println("ENTER ACCOUNT TYPE");
					String accountType=sc.next().toUpperCase();
					bean.setAccountType(accountType);
					valid10=service.validateAccountType(accountType,bean);
					if(valid10){
						break;
					}else{
						System.err.println("Please enter valid Account Type. Please select  S for Savings Account or C for Current Account");
					}
				}while(!valid10);
				boolean isAdded = service.createAccount(bean);
				if (isAdded) {
					double Balance=0;
					System.out.println("Record added successfully");
					System.out.println(bean);
					System.out.println("ENTER OPENING BALANCE:");
					System.out.println("Amount should be in numbers EX:1000,2000,3000");
					Balance=sc.nextDouble();
					boolean valid12=service.validateOpeningBalance(Balance);
					if(valid12){
						//bean.setBalance(Balance);
						service.deposit(bean,bean.getAccountNo(),bean.getPin(), Balance);
						System.out.println("Your AccountNo:"+bean.getAccountNo()+" Balance:"+bean.getBalance());
					}else{
						System.err.println("Please enter valid amount");
					}
				} else {
					System.err.println("Record not added..");
				}
				break;
			case 2:
				int section=2;
				checkAccountNumberandPin(section);
				break;

			case 3:
				int section1=3;
				checkAccountNumberandPin(section1);
				break;
			case 4:
				int section2=4;
				checkAccountNumberandPin(section2);
				break;
			case 5:
				int section3=5;
				checkAccountNumberandPin(section3);
				break;
			case 6:
				int section4=6;
				checkAccountNumberandPin(section4);
				break;
			case 7:
				System.out.println("********************************************");
				System.out.println("--------------------------------------------");
				System.out.println("Thank You for using Our Banking Service..");
				System.out.println("--------------------------------------------");
				System.out.println("********************************************");
				sc.close();
				System.exit(0);
				break;

			default:
				System.out.println("Invalid choice");
				break;
			}
		}
	}
	private static void checkAccountNumberandPin(int section) throws CustomerNotFoundException {
		int accountNumber=0;
		int pin=0;
		do{
			Scanner sc1=new Scanner(System.in);
            System.out.println("Enter Account Number");
			try{
				accountNumber=sc1.nextInt();
			}catch(InputMismatchException e){
				System.out.println("Please enter valid Account Number.\nAccount Number Is a 10 digit Number");
			}finally{
				sc1.close();
			}
		}while(accountNumber<111110000||accountNumber>1111199999);
		do{
			Scanner sc2=new Scanner(System.in);

			try{
				pin=sc2.nextInt();

			}catch(InputMismatchException e){
				System.out.println("Please enter valid pin.\nPin is a 4digit number");
			}finally{
				sc2.close();
			}
		}while(pin<1000||pin>9999);
		if(service.validateAccountNumber(accountNumber)){
			if(service.validatePin(pin,accountNumber)){
				double amount=0;
				if(section==2){
					System.out.println("Balance :"+service.showBalance(accountNumber, pin));
				}
				else if(section==3){
					double balanceBefore=service.showBalance(accountNumber, pin);
					do{
						Scanner sc2=new Scanner(System.in);
						System.out.println("Enter amount to deposit");
						try{
							amount=sc2.nextDouble();

						}catch(InputMismatchException e){
							System.out.println("Please enter valid amount greater than 0");
						}finally{
							sc2.close();
						}
					}while(amount<0);
					Customer c=service.displayCustomer(accountNumber);
					double balanceAfter=service.deposit(c, accountNumber, pin, amount);
					if(balanceAfter>balanceBefore){
						System.out.println("Successflly Deposited");
						System.out.println("Current Balance"+balanceAfter);
					}else{
						System.out.println("Deposition failed");
					}
				}else if(section==4){
					double balanceBefore=service.showBalance(accountNumber, pin);
					do{
						Scanner sc2=new Scanner(System.in);
						System.out.println("Enter Withdrawal amount");
						try{
							amount=sc2.nextDouble();

						}catch(InputMismatchException e){
							System.out.println("Please enter valid pin.\nPin is a 4digit number");
						}finally{
							sc2.close();
						}
					}while(amount<0);
					Customer c=service.displayCustomer(accountNumber);
					double balanceAfter=service.deposit(c, accountNumber, pin, amount);
					if(balanceAfter<balanceBefore){
						System.out.println("Successflly Deposited");
						System.out.println("Current Balance"+balanceAfter);
					}else{
						System.out.println("Insufficient Balance...");
					}
				}else if(section==5){
					Scanner sc2=new Scanner(System.in);
					int accountNumber1=0;
					do{
						Scanner sc1=new Scanner(System.in);
						System.out.println("Enter Account Number to Transfer:");
						try{
							accountNumber1=sc1.nextInt();
						}catch(InputMismatchException e){
							System.out.println("Please enter valid Account Number.\nAccount Number Is a 10 digit Number");
						}finally{
							sc1.close();
						}
					}while(accountNumber1<111110000||accountNumber1>1111199999);
					if(service.validateAccountNumber(accountNumber)){
						do{
							System.out.println("Enter amont to transfer");
							try{
								amount=sc2.nextDouble();

							}catch(InputMismatchException e){
								System.out.println("Please enter valid pin.\nPin is a 4digit number");
							}finally{
								sc2.close();
							}
						}while(amount<0);
						Customer c=service.displayCustomer(accountNumber);
						Customer b=service.displayCustomer(accountNumber);
						boolean balanceAfter=service.fundTransfer(c, b, amount, accountNumber, accountNumber, pin);
						if(balanceAfter){
							System.out.println("Transaction Successful");
							System.out.println("Account No:"+accountNumber+"Amount after deduction:"+c.getBalance());
							System.out.println("Account No:"+accountNumber+"Amount after Credit:"+b.getBalance());
						}else{
							System.out.println("Insufficient Balance...Transaction Failed");
						}
					}else{
						System.out.println("Enter Valid account number");
					}
				}else{
					Customer c=service.displayCustomer(accountNumber);
					List<Transaction> list=service.printTransactions(accountNumber, pin);
					if(list==null){
						System.out.println("Please enter Correct Account No. and Correct pin");
					}else{
						System.out.println("   Sl No.\t\t Date \t\t\tWithdrawals\t\t   Deposit\t\tBalance");
						System.out.println("------------------------------------------------------------------------------------------");
						Iterator<Transaction> it = list.iterator();
						System.out.println("\t\t\t\t\t\t\t  \t  Opening Balance     ");
						System.out.println(it.next());
						while(it.hasNext()){
							System.out.println(it.next());
						}
						System.out.println("\t\t\t\t\t\t\t  \t  Current Balance\t"+c.getBalance());
					}



				}

			}else{
				throw new CustomerNotFoundException("Enter Valid Pin");
			}
		}else{
			throw new CustomerNotFoundException("Enter Valid Account Number.");
		}
	}
}
