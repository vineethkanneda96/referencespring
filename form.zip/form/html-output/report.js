$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capg/form/ui/formfeatures.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Vineeth"
    }
  ],
  "line": 2,
  "name": "",
  "description": "",
  "id": "",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 3406938685,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Test name",
  "description": "",
  "id": ";test-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "comments": [
    {
      "line": 8,
      "value": "#Given check user name"
    }
  ],
  "line": 9,
  "name": "enter empty value in user name text box",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "print error message for name field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_user_name_text_box()"
});
formatter.result({
  "duration": 153459354,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_name_field()"
});
formatter.result({
  "duration": 6086706077,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 2767891989,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Test city",
  "description": "",
  "id": ";test-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "comments": [
    {
      "line": 13,
      "value": "#Given check user city"
    }
  ],
  "line": 14,
  "name": "enter empty value in city text box",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "print error message for city field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_city_text_box()"
});
formatter.result({
  "duration": 200809516,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_city_field()"
});
formatter.result({
  "duration": 4210367908,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 2938755895,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Test password",
  "description": "",
  "id": ";test-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "comments": [
    {
      "line": 18,
      "value": "#Given check user password"
    }
  ],
  "line": 19,
  "name": "enter empty value in password text box",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "print error message for password field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_password_text_box()"
});
formatter.result({
  "duration": 282561851,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_password_field()"
});
formatter.result({
  "duration": 4138511572,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 2838304373,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Test gender",
  "description": "",
  "id": ";test-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "comments": [
    {
      "line": 23,
      "value": "#Given check user gender"
    }
  ],
  "line": 24,
  "name": "no gender is selected",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "print error message for gender",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.no_gender_is_selected()"
});
formatter.result({
  "duration": 284478780,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_gender()"
});
formatter.result({
  "duration": 4260448044,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 2887642842,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "Test language",
  "description": "",
  "id": ";test-language",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "comments": [
    {
      "line": 28,
      "value": "#Given check user languages"
    }
  ],
  "line": 29,
  "name": "no language is selected",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "print error message for language",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.no_language_is_selected()"
});
formatter.result({
  "duration": 385469734,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_language()"
});
formatter.result({
  "duration": 4166380269,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 2919950052,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "Test number",
  "description": "",
  "id": ";test-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "comments": [
    {
      "line": 33,
      "value": "#Given check user number"
    }
  ],
  "line": 34,
  "name": "enter empty value in the user my number text box",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "print error message for number field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_the_user_my_number_text_box()"
});
formatter.result({
  "duration": 542815043,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_number_field()"
});
formatter.result({
  "duration": 4285997802,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 2783925197,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "Test email",
  "description": "",
  "id": ";test-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "comments": [
    {
      "line": 38,
      "value": "#Given check user email"
    }
  ],
  "line": 39,
  "name": "enter empty value in the user email box",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "print error message for email field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_the_user_email_box()"
});
formatter.result({
  "duration": 605845219,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_email_field()"
});
formatter.result({
  "duration": 4273335732,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 2791980566,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "Test mobile number",
  "description": "",
  "id": ";test-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "comments": [
    {
      "line": 43,
      "value": "#Given check user mobile number"
    }
  ],
  "line": 44,
  "name": "enter empty value in the user mobile number box",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "print error message for mobile number field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_the_user_mobile_number_box()"
});
formatter.result({
  "duration": 661851304,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_mobile_number_field()"
});
formatter.result({
  "duration": 6125089786,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is in the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.user_is_in_the_home_page()"
});
formatter.result({
  "duration": 2938880600,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "when all details are correctly entered",
  "description": "",
  "id": ";when-all-details-are-correctly-entered",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 48,
  "name": "all details are correctly entered",
  "keyword": "When "
});
formatter.step({
  "line": 49,
  "name": "display success page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.all_details_are_correctly_entered()"
});
formatter.result({
  "duration": 31587,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.display_success_page()"
});
formatter.result({
  "duration": 699170506,
  "status": "passed"
});
});