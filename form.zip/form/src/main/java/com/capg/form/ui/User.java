package com.capg.form.ui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class User {
	
	WebDriver wd;

	public User(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	@FindBy(how=How.NAME, using="companyName")
	@CacheLookup
	WebElement companyName;

	@FindBy(how=How.NAME, using="userName")
	@CacheLookup
	WebElement name;
	
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(how=How.NAME, using="password")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"male\"]")
	@CacheLookup
	WebElement male;
	
	@FindBy(xpath="//*[@id=\"female\"]")
	@CacheLookup
	WebElement female;
	
	@FindBy(xpath="//*[@id=\"eng\"]")
	@CacheLookup
	WebElement english;
	
	@FindBy(xpath="//*[@id=\"tel\"]")
	@CacheLookup
	WebElement telugu;
	
	@FindBy(xpath="//*[@id=\"tam\"]")
	@CacheLookup
	WebElement tamil;
	
	@FindBy(xpath="/html/body/form/input[11]")
	@CacheLookup
	WebElement number;
	
	@FindBy(xpath="/html/body/form/input[12]")
	@CacheLookup
	WebElement email;
	
	@FindBy(how=How.NAME, using="mobile")
	@CacheLookup
	WebElement mobileNumber;
	
	@FindBy(xpath="/html/body/form/button")
	@CacheLookup
	WebElement store;

	public WebElement getStore() {
		return store;
	}

	public void setStore() {
		store.click();
	}

	public WebElement getCompanyName() {
		return companyName;
	}

	public void setCompanyName(WebElement companyName) {
		this.companyName = companyName;
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getMale() {
		return male;
	}

	public void setMale() {
		male.click();
	}

	public WebElement getFemale() {
		return female;
	}

	public void setFemale() {
		female.click();
	}

	public void setGender() {
		male.click();
	}

	public WebElement getEnglish() {
		return english;
	}

	public void setEnglish() {
		english.click();
	}

	public WebElement getTelugu() {
		return telugu;
	}

	public void setTelugu() {
		telugu.click();
	}

	public WebElement getTamil() {
		return tamil;
	}

	public void setTamil() {
		tamil.click();
	}

	public WebElement getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number.sendKeys(number);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber.sendKeys(mobileNumber);
	}

	public User() {
		super();
	}

	public User(WebElement companyName, WebElement name, WebElement city, WebElement password,
		 WebElement number, WebElement email, WebElement mobileNumber) {
		super();
		this.companyName = companyName;
		this.name = name;
		this.city = city;
		this.password = password;
		this.number = number;
		this.email = email;
		this.mobileNumber = mobileNumber;
	}
	
}
