function myfunction() {
	

	if (document.forms["form"]["userName"].value == "") {
		window.alert("Please fill the Name");
		return false;
		}
	else if (document.forms["form"]["city"].value == "") {
		window.alert("Please fill the City");
		return false;
		}
	else if (document.forms["form"]["password"].value == "") {
		window.alert("Please fill the Password");
		return false;
		}
	else if (document.getElementById("male").checked == false && document.getElementById("female").checked == false) {
		window.alert("Please select male or female");
		return false;
		}
	else if (document.getElementById("eng").checked==false && document.getElementById("tel").checked==false&& document.getElementById("tam").checked == false) {
		window.alert("Please select atleast one language");
		return false;
		}
	else if (document.forms["form"]["number"].value == ""||((document.forms["form"]["number"].value)%10!=0) ) {
		window.alert("Please fill the max number value 100 in the steps of 10 Ex: 10 20 30,...");
		return false;
		}
	else if (document.forms["form"]["email"].value == "") {
		window.alert("Please fill the email. Ex: jshkdj@kjdk.com");
		return false;
		}
	else if (document.forms["form"]["mobile"].value == "") {
		window.alert("Please fill the mobile number details. Ex: 8888888888");
		return false;
		}
		else {
	window.alert(" completed Successfully.");
	return true;
//	window.location="success.html";
		}
	
}