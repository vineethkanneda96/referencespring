package com.capg.form.ui;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private User user;
	private WebDriver driver;
	
	@Given("^user is in the home page$")
	public void user_is_in_the_home_page() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	}
	
	/*@Given("^check user name$")
	public void check_user_name() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	    
	}*/

	@When("^enter empty value in user name text box$")
	public void enter_empty_value_in_user_name_text_box() throws Throwable {
		user.setName("");
		user.setStore();
	    
	}

	@Then("^print error message for name field$")
	public void print_error_message_for_name_field() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	    
	}

/*	@Given("^check user city$")
	public void check_user_city() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	   
	}*/

	@When("^enter empty value in city text box$")
	public void enter_empty_value_in_city_text_box() throws Throwable {
		user.setName("vineeth");
		user.setCity("");
		user.setStore();
	}

	@Then("^print error message for city field$")
	public void print_error_message_for_city_field() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	    
	}

	/*@Given("^check user password$")
	public void check_user_password() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	    
	}*/

	@When("^enter empty value in password text box$")
	public void enter_empty_value_in_password_text_box() throws Throwable {
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("");
		user.setStore();
	    
	}

	@Then("^print error message for password field$")
	public void print_error_message_for_password_field() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	   
	}

	/*@Given("^check user gender$")
	public void check_user_gender() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	    
	}*/

	@When("^no gender is selected$")
	public void no_gender_is_selected() throws Throwable {
		
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("helklo");
		user.setStore();
	}

	@Then("^print error message for gender$")
	public void print_error_message_for_gender() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	    
	}
	
	/*@Given("^check user languages$")
	public void check_user_languages() throws Throwable {
	    
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	}*/

	@When("^no language is selected$")
	public void no_language_is_selected() throws Throwable {
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("helklo");
		user.setMale();
		user.setStore();
	    
	}

	@Then("^print error message for language$")
	public void print_error_message_for_language() throws Throwable {
	    
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}
	
	/*@Given("^check user number$")
	public void check_user_number() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	    
	}*/

	@When("^enter empty value in the user my number text box$")
	public void enter_empty_value_in_the_user_my_number_text_box() throws Throwable {
		
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("helklo");
		user.setMale();
		user.setEnglish();
		user.setTelugu();
		user.setNumber("3");
		user.setStore();
	   
	}

	@Then("^print error message for number field$")
	public void print_error_message_for_number_field() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	   
	}
	
	/*@Given("^check user email$")
	public void check_user_email() throws Throwable {
	    
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	}*/

	@When("^enter empty value in the user email box$")
	public void enter_empty_value_in_the_user_email_box() throws Throwable {
		
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("helklo");
		user.setMale();
		user.setEnglish();
		user.setTelugu();
		user.setNumber("10");
		user.setEmail("");
		user.setStore();
	    
	}

	@Then("^print error message for email field$")
	public void print_error_message_for_email_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}
	
	/*@Given("^check user mobile number$")
	public void check_user_mobile_number() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User(driver);
		driver.get("file:///D:/SpringPrograms/form/src/main/java/com/capg/form/ui/form.html");
	    
	}*/

	@When("^enter empty value in the user mobile number box$")
	public void enter_empty_value_in_the_user_mobile_number_box() throws Throwable {
		
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("helklo");
		user.setMale();
		user.setEnglish();
		user.setTelugu();
		user.setNumber("10");
		user.setEmail("ejfer@lksjd.com");
		user.setMobileNumber("");
		user.setStore();
	    
	}

	@Then("^print error message for mobile number field$")
	public void print_error_message_for_mobile_number_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}
	
	@When("^all details are correctly entered$")
	public void all_details_are_correctly_entered() throws Throwable {
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("helklo");
		user.setMale();
		user.setEnglish();
		user.setTelugu();
		user.setNumber("10");
		user.setEmail("ejfer@lksjd.com");
		user.setMobileNumber("9999999999");
		user.setStore();
	}

	@Then("^display success page$")
	public void display_success_page() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	    
	}

}
