$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/capf/form1/ui/formfeatures1.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Vineeth"
    }
  ],
  "line": 2,
  "name": "",
  "description": "",
  "id": "",
  "keyword": "Feature"
});
formatter.before({
  "duration": 111168,
  "status": "passed"
});
formatter.scenario({
  "line": 5,
  "name": "Test name",
  "description": "",
  "id": ";test-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "enter invalid details in user name text box",
  "rows": [
    {
      "cells": [
        "vineeth"
      ],
      "line": 7
    },
    {
      "cells": [
        "Vineeth kumar"
      ],
      "line": 8
    },
    {
      "cells": [
        "js"
      ],
      "line": 9
    },
    {
      "cells": [
        "g"
      ],
      "line": 10
    },
    {
      "cells": [
        ""
      ],
      "line": 11
    },
    {
      "cells": [
        "1234"
      ],
      "line": 12
    },
    {
      "cells": [
        "@%$%"
      ],
      "line": 13
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.enter_invalid_details_in_user_name_text_box(DataTable)"
});
formatter.result({
  "duration": 61509576106,
  "status": "passed"
});
formatter.before({
  "duration": 34048,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "Test city",
  "description": "",
  "id": ";test-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 16,
  "name": "enter invalid details in city text box",
  "rows": [
    {
      "cells": [
        "1234"
      ],
      "line": 17
    },
    {
      "cells": [
        ""
      ],
      "line": 18
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.enter_invalid_details_in_city_text_box(DataTable)"
});
formatter.result({
  "duration": 14657652148,
  "status": "passed"
});
formatter.before({
  "duration": 29535,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Test password",
  "description": "",
  "id": ";test-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "enter invalid details in password text box",
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.enter_invalid_details_in_password_text_box()"
});
formatter.result({
  "duration": 7283419766,
  "status": "passed"
});
formatter.before({
  "duration": 24613,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Test gender",
  "description": "",
  "id": ";test-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "no gender is selected",
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.no_gender_is_selected()"
});
formatter.result({
  "duration": 9317400094,
  "status": "passed"
});
formatter.before({
  "duration": 57430,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Test language",
  "description": "",
  "id": ";test-language",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "no language is selected",
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.no_language_is_selected()"
});
formatter.result({
  "duration": 9354053805,
  "status": "passed"
});
formatter.before({
  "duration": 68916,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "Test number",
  "description": "",
  "id": ";test-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 30,
  "name": "enter invalid details in the user my number text box",
  "rows": [
    {
      "cells": [
        ""
      ],
      "line": 31
    },
    {
      "cells": [
        "1234"
      ],
      "line": 32
    },
    {
      "cells": [
        "1"
      ],
      "line": 33
    },
    {
      "cells": [
        "4"
      ],
      "line": 34
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.enter_invalid_details_in_the_user_my_number_text_box(DataTable)"
});
formatter.result({
  "duration": 34330193532,
  "status": "passed"
});
formatter.before({
  "duration": 61943,
  "status": "passed"
});
formatter.scenario({
  "line": 36,
  "name": "Test email",
  "description": "",
  "id": ";test-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 37,
  "name": "enter invalid details in the user email box",
  "rows": [
    {
      "cells": [
        ""
      ],
      "line": 38
    },
    {
      "cells": [
        "1234"
      ],
      "line": 39
    },
    {
      "cells": [
        "hsbbdsd"
      ],
      "line": 40
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.enter_invalid_details_in_the_user_email_box(DataTable)"
});
formatter.result({
  "duration": 24942352611,
  "status": "passed"
});
formatter.before({
  "duration": 22152,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "Test mobile number",
  "description": "",
  "id": ";test-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 43,
  "name": "enter invalid details in the user mobile number box",
  "rows": [
    {
      "cells": [
        "999999999"
      ],
      "line": 44
    },
    {
      "cells": [
        "99999999999"
      ],
      "line": 45
    },
    {
      "cells": [
        ""
      ],
      "line": 46
    },
    {
      "cells": [
        "jhdsbdj"
      ],
      "line": 47
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.enter_invalid_details_in_the_user_mobile_number_box(DataTable)"
});
formatter.result({
  "duration": 35209755043,
  "status": "passed"
});
formatter.before({
  "duration": 20921,
  "status": "passed"
});
formatter.scenario({
  "line": 49,
  "name": "when all details are correctly entered",
  "description": "",
  "id": ";when-all-details-are-correctly-entered",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "all details are correctly entered",
  "keyword": "When "
});
formatter.match({
  "location": "StepDef1.all_details_are_correctly_entered()"
});
formatter.result({
  "duration": 7499103675,
  "status": "passed"
});
});