package com.capf.form1.ui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class User1 {
	
	WebDriver wd;

	public User1(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	@FindBy(how=How.NAME, using="companyName")
	@CacheLookup
	WebElement companyName;

	@FindBy(how=How.NAME, using="userName")
	@CacheLookup
	WebElement name;
	
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(how=How.NAME, using="password")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"male\"]")
	@CacheLookup
	WebElement male;
	
	@FindBy(xpath="//*[@id=\"female\"]")
	@CacheLookup
	WebElement female;
	
	@FindBy(xpath="//*[@id=\"eng\"]")
	@CacheLookup
	WebElement english;
	
	@FindBy(xpath="//*[@id=\"tel\"]")
	@CacheLookup
	WebElement telugu;
	
	@FindBy(xpath="//*[@id=\"tam\"]")
	@CacheLookup
	WebElement tamil;
	
	@FindBy(xpath="/html/body/form/input[11]")
	@CacheLookup
	WebElement number;
	
	@FindBy(xpath="/html/body/form/input[12]")
	@CacheLookup
	WebElement email;
	
	@FindBy(how=How.NAME, using="mobile")
	@CacheLookup
	WebElement mobileNumber;
	
	@FindBy(xpath="/html/body/form/button")
	@CacheLookup
	WebElement store;

	public void setStore() {
		store.click();
	}

	public void setCompanyName(WebElement companyName) {
		this.companyName = companyName;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void setMale() {
		male.click();
	}

	public void setFemale() {
		female.click();
	}

	public void setEnglish() {
		english.click();
	}

	public void setTelugu() {
		telugu.click();
	}

	public void setTamil() {
		tamil.click();
	}

	public void setNumber(String number) {
		this.number.sendKeys(number);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber.sendKeys(mobileNumber);
	}

	public User1() {
		super();
	}

	public User1(WebElement companyName, WebElement name, WebElement city, WebElement password,
		 WebElement number, WebElement email, WebElement mobileNumber) {
		super();
		this.companyName = companyName;
		this.name = name;
		this.city = city;
		this.password = password;
		this.number = number;
		this.email = email;
		this.mobileNumber = mobileNumber;
	}
	

}
