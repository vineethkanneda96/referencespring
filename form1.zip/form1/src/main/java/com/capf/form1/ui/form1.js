function myfunction() {
	
    var mobileReg=/^[7-9]{1}[0-9]{9}$/; 
    var emailReg=/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
    var nameReg=/^[a-zA-Z]{3,}$/;
    var cityReg=/^[a-zA-Z]+$/;
    var passwordReg=/[a-zA-Z0-9.]+$/; 
    var numberReg=/[1]?[0-9]{2}$/;	
  
	if (!nameReg.test(document.forms["form"]["userName"].value)) {
		alert("Please fill the Name. Name should be atleast 3 letters Ex: vineeth");
		}
	else if (!cityReg.test(document.forms["form"]["city"].value)) {
		alert("Please fill the City. City name should contain alphabets Ex: Hyderabad");
		}
	else if (!passwordReg.test(document.forms["form"]["password"].value)) {
		alert("Please fill the Password");
		}
	else if (document.getElementById("male").checked == false && document.getElementById("female").checked == false) {
		alert("Please select male or female");
		}
	else if (document.getElementById("eng").checked==false && document.getElementById("tel").checked==false&& document.getElementById("tam").checked == false) {
		alert("Please select atleast one language");
		}
	else if ((!numberReg.test(document.forms["form"]["number"].value))||((document.forms["form"]["number"].value)%10!=0)) {
		alert("Please fill the max number value 100 in the steps of 10 Ex: 10 20 30,...");
		}
	else if (!emailReg.test(document.forms["form"]["email"].value)) {
		alert("Please fill the email. Ex: jshkdj@kjdk.com");
		}
	else if (!mobileReg.test(document.forms["form"]["mobile"].value)) {
		alert("Please fill the mobile number details. Ex: 8888888888");
		}
		else {
	    alert(" completed Successfully.");
	   // window.location="success.html";
		}
}