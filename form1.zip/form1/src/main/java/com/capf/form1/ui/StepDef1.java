package com.capf.form1.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.When;

public class StepDef1 {

	private User1 user;
	private WebDriver driver;
	
	@Before
	public void initialize() {
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
	}

	List<String> li=new ArrayList<String>();
	@When("^enter invalid details in user name text box$")
	public void enter_invalid_details_in_user_name_text_box(DataTable arg1) throws Throwable {

		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		li=arg1.asList(String.class);
		for(int i=0;i<li.size();i++) {
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			user = new User1(driver);
			driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
			user.setName(li.get(i));
			System.out.println(li.get(i));
			user.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}

	}

	@When("^enter invalid details in city text box$")
	public void enter_invalid_details_in_city_text_box(DataTable arg1) throws Throwable {

		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		li=arg1.asList(String.class);
		for(int i=0;i<li.size();i++) {
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			user = new User1(driver);
			driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
			user.setName("vineeth");
			user.setCity(li.get(i));
			System.out.println(li.get(i));
			user.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}

	}

	@When("^enter invalid details in password text box$")
	public void enter_invalid_details_in_password_text_box() throws Throwable {
		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User1(driver);
		driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
		user.setName("vineeth");
		user.setCity("hyderabad");
		//user.setPassword("");
		user.setStore();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();

	}

	@When("^no gender is selected$")
	public void no_gender_is_selected() throws Throwable {
		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User1(driver);
		driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("hello");
		user.setStore();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^no language is selected$")
	public void no_language_is_selected() throws Throwable {

		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User1(driver);
		driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("hello");
		user.setMale();
		user.setStore();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();

	}

	@When("^enter invalid details in the user my number text box$")
	public void enter_invalid_details_in_the_user_my_number_text_box(DataTable arg1) throws Throwable {

		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		li=arg1.asList(String.class);
		for(int i=0;i<li.size();i++) {
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			user = new User1(driver);
			driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
			user.setName("vineeth");
			user.setCity("hyderabad");
			user.setPassword("hello");
			user.setMale();
			user.setEnglish();
			user.setTelugu();
			System.out.println(li.get(i));
			user.setNumber(li.get(i));
			user.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}

	}

	@When("^enter invalid details in the user email box$")
	public void enter_invalid_details_in_the_user_email_box(DataTable arg1) throws Throwable {

		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		li=arg1.asList(String.class);
		for(int i=0;i<li.size();i++) {
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			user = new User1(driver);
			driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
			user.setName("vineeth");
			user.setCity("hyderabad");
			user.setPassword("hello");
			user.setMale();
			user.setEnglish();
			user.setTelugu();
			user.setNumber("10");
			System.out.println(li.get(i));
			user.setEmail(li.get(i));
			user.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}

	}

	@When("^enter invalid details in the user mobile number box$")
	public void enter_invalid_details_in_the_user_mobile_number_box(DataTable arg1) throws Throwable {

		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		li=arg1.asList(String.class);
		for(int i=0;i<li.size();i++) {
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			user = new User1(driver);
			driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
			user.setName("vineeth");
			user.setCity("hyderabad");
			user.setPassword("hello");
			user.setMale();
			user.setEnglish();
			user.setTelugu();
			user.setNumber("10");
			user.setEmail("ejfer@lksjd.com");
			System.out.println(li.get(i));
			user.setMobileNumber(li.get(i));
			user.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}

	}

	@When("^all details are correctly entered$")
	public void all_details_are_correctly_entered() throws Throwable {

		//System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		user = new User1(driver);
		driver.get("file:///D:/SpringPrograms/form1/src/main/java/com/capf/form1/ui/form1.html");
		user.setName("vineeth");
		user.setCity("hyderabad");
		user.setPassword("hello");
		user.setMale();
		user.setEnglish();
		user.setTelugu();
		user.setNumber("10");
		user.setEmail("ejfer@lksjd.com");
		user.setMobileNumber("9999999999");
		user.setStore();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		//driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		//driver.close();

	}

}
